// config/database.js
module.exports = {

    'url' : 'mongodb+srv://kellychhe:Poop00@cluster0.2unid.mongodb.net/Boba?retryWrites=true&w=majority',
    'dbName': 'boba'
};
